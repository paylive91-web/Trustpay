import { Switch, Route, Router as WouterRouter } from "wouter";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import NotFound from "@/pages/not-found";

import Home from "@/pages/home";
import Login from "@/pages/login";
import Register from "@/pages/register";
import Buy from "@/pages/buy";
import Sell from "@/pages/sell";
import Orders from "@/pages/orders";
import Transactions from "@/pages/transactions";
import Support from "@/pages/support";
import Profile from "@/pages/profile";
import Invite from "@/pages/invite";
import Info from "@/pages/info";
import UpiManage from "@/pages/upi-manage";

import AdminLogin from "@/pages/admin/login";
import AdminDashboard from "@/pages/admin/dashboard";
import AdminOrders from "@/pages/admin/orders";
import AdminDisputes from "@/pages/admin/disputes";
import AdminUsers from "@/pages/admin/users";
import AdminSettings from "@/pages/admin/settings";
import AdminLinksMedia from "@/pages/admin/links-media";
import AdminDepositTasks from "@/pages/admin/deposit-tasks";
import AdminFraudWatch from "@/pages/admin/fraud-watch";
import AdminHighValue from "@/pages/admin/high-value";
import AdminAgents from "@/pages/admin/agents";
import AdminReports from "@/pages/admin/reports";
import AdminActivityLog from "@/pages/admin/activity-log";
import AdminSmsLearning from "@/pages/admin/sms-learning";

const queryClient = new QueryClient();

function Router() {
  return (
    <Switch>
      <Route path="/" component={Home} />
      <Route path="/login" component={Login} />
      <Route path="/register" component={Register} />
      <Route path="/buy" component={Buy} />
      <Route path="/sell" component={Sell} />
      <Route path="/orders" component={Orders} />
      <Route path="/transactions" component={Transactions} />
      <Route path="/support" component={Support} />
      <Route path="/profile" component={Profile} />
      <Route path="/invite" component={Invite} />
      <Route path="/info" component={Info} />
      <Route path="/upi" component={UpiManage} />

      <Route path="/admin" component={AdminLogin} />
      <Route path="/admin/login" component={AdminLogin} />
      <Route path="/admin/dashboard" component={AdminDashboard} />
      <Route path="/admin/orders" component={AdminOrders} />
      <Route path="/admin/disputes" component={AdminDisputes} />
      <Route path="/admin/users" component={AdminUsers} />
      <Route path="/admin/settings" component={AdminSettings} />
      <Route path="/admin/links-media" component={AdminLinksMedia} />
      <Route path="/admin/deposit-tasks" component={AdminDepositTasks} />
      <Route path="/admin/fraud-watch" component={AdminFraudWatch} />
      <Route path="/admin/high-value" component={AdminHighValue} />
      <Route path="/admin/agents" component={AdminAgents} />
      <Route path="/admin/reports" component={AdminReports} />
      <Route path="/admin/activity-log" component={AdminActivityLog} />
      <Route path="/admin/sms-learning" component={AdminSmsLearning} />

      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <WouterRouter base={import.meta.env.BASE_URL.replace(/\/$/, "")}>
          <Router />
        </WouterRouter>
        <Toaster />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
