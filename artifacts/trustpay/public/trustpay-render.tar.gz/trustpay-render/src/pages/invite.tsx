import React, { useState } from "react";
import { useGetMe, useGetAppSettings } from "@workspace/api-client-react";
import Layout from "@/components/layout";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { useToast } from "@/hooks/use-toast";
import { Gift, Copy, Share2, Users, TrendingUp, IndianRupee, Award, Flame, Download } from "lucide-react";
import { useQuery } from "@tanstack/react-query";
import { getAuthToken } from "@/lib/auth";

export default function Invite() {
  const { toast } = useToast();
  const { data: user, isLoading } = useGetMe();
  useGetAppSettings();

  const referralCode = (user as any)?.referralCode || "";
  const inviteEarnings = (user as any)?.inviteEarnings || 0;
  const inviteEarningsL2 = (user as any)?.inviteEarningsL2 || 0;
  const { data: invitees = [] } = useQuery<any[]>({
    queryKey: ["invitees"],
    queryFn: async () => {
      const token = getAuthToken();
      const res = await fetch(`${import.meta.env.BASE_URL.replace(/\/$/, "")}/api/auth/invitees`, {
        headers: { ...(token ? { Authorization: `Bearer ${token}` } : {}) },
      });
      return res.json();
    },
    enabled: !!user,
  });
  const totalEarnings = inviteEarnings + inviteEarningsL2;
  const { data: appSettings } = useGetAppSettings();
  const agentTiers = Array.isArray((appSettings as any)?.agentTiers) ? (appSettings as any).agentTiers : [];
  const todayActiveCount = invitees.filter((u: any) => Number(u.todayDeposits || 0) > 0).length;
  const currentDailyReward = agentTiers
    .filter((tier: any) => todayActiveCount >= Number(tier.minActiveDeposits || 0))
    .reduce((sum: number, tier: any) => sum + Number(tier.reward || 0), 0);
  const inviteShareImageUrl = (appSettings as any)?.inviteShareImageUrl || "";
  const shareUrl = `${window.location.origin}${import.meta.env.BASE_URL.replace(/\/$/, "")}/register?ref=${referralCode}`;

  const handleCopyCode = () => {
    if (!referralCode) return;
    navigator.clipboard.writeText(referralCode);
    toast({ title: "Referral code copied!" });
  };

  const handleCopyLink = () => {
    navigator.clipboard.writeText(shareUrl);
    toast({ title: "Invite link copied!" });
  };

  const dataUrlToBlob = (dataUrl: string): Blob => {
    const [header, b64] = dataUrl.split(",");
    const mime = header.match(/:(.*?);/)?.[1] || "image/jpeg";
    const binary = atob(b64);
    const bytes = new Uint8Array(binary.length);
    for (let i = 0; i < binary.length; i++) bytes[i] = binary.charCodeAt(i);
    return new Blob([bytes], { type: mime });
  };

  const handleSaveImage = () => {
    if (!inviteShareImageUrl) return;
    try {
      const blob = inviteShareImageUrl.startsWith("data:")
        ? dataUrlToBlob(inviteShareImageUrl)
        : undefined;
      const url = blob ? URL.createObjectURL(blob) : inviteShareImageUrl;
      const a = document.createElement("a");
      a.href = url;
      a.download = "trustpay-invite.jpg";
      a.click();
      if (blob) setTimeout(() => URL.revokeObjectURL(url), 1000);
      toast({ title: "Image save ho rahi hai", description: "Gallery mein save hone ke baad share karo" });
    } catch {
      toast({ title: "Save failed", variant: "destructive" });
    }
  };

  const handleShare = async () => {
    const text = `Join TrustPay and start earning! 6% earning platform. Use my referral code: ${referralCode}\n${shareUrl}`;
    if (navigator.share) {
      // Try sharing with image via Web Share API
      if (inviteShareImageUrl) {
        try {
          const blob = inviteShareImageUrl.startsWith("data:")
            ? dataUrlToBlob(inviteShareImageUrl)
            : await fetch(inviteShareImageUrl).then((r) => r.blob());
          const ext = blob.type.includes("png") ? "png" : "jpg";
          const file = new File([blob], `trustpay-invite.${ext}`, { type: blob.type || "image/jpeg" });
          if (navigator.canShare && navigator.canShare({ files: [file] })) {
            await navigator.share({ title: "Join TrustPay", text, files: [file] });
            return;
          }
        } catch {}
        // Image share not supported — prompt user to save image manually
        toast({
          title: "Image alag se save karo",
          description: "Neeche 'Save Image' dabao → gallery se attach karke share karo",
        });
      }
      // Text + link share
      try {
        await navigator.share({ title: "Join TrustPay", text: `Join TrustPay and start earning! 6% earning platform. Use my referral code: ${referralCode}`, url: shareUrl });
      } catch {}
    } else {
      handleCopyLink();
    }
  };

  if (isLoading) {
    return (
      <Layout>
        <div className="p-4 space-y-4">
          <Skeleton className="h-40 w-full rounded-xl" />
          <Skeleton className="h-32 w-full rounded-xl" />
          <Skeleton className="h-48 w-full rounded-xl" />
        </div>
      </Layout>
    );
  }

  return (
    <Layout>
      <div className="p-4 space-y-4">
        {/* Hero */}
        <div className="bg-gradient-to-br from-primary to-primary/80 rounded-2xl p-6 text-primary-foreground text-center">
          <div className="w-16 h-16 bg-primary-foreground/20 rounded-full flex items-center justify-center mx-auto mb-4">
            <Gift className="w-8 h-8" />
          </div>
          <h1 className="text-2xl font-bold mb-2">Invite & Earn</h1>
          <p className="text-primary-foreground/80 text-sm">Earn commissions when your friends deposit</p>
          <div className="mt-4 grid grid-cols-2 gap-3">
            <div className="bg-primary-foreground/10 rounded-xl p-3">
              <div className="text-2xl font-bold">1%</div>
              <div className="text-xs text-primary-foreground/70">Direct Invite (L1)</div>
            </div>
            <div className="bg-primary-foreground/10 rounded-xl p-3">
              <div className="text-2xl font-bold">0.1%</div>
              <div className="text-xs text-primary-foreground/70">2nd Level (L2)</div>
            </div>
          </div>
        </div>

        {/* Earnings Summary */}
        <div className="grid grid-cols-2 gap-3">
          <Card className="border-none shadow-sm">
            <CardContent className="p-4 text-center">
              <div className="text-xs text-muted-foreground mb-1">L1 Earnings</div>
              <div className="text-xl font-bold text-primary flex items-center justify-center">
                <IndianRupee className="w-4 h-4 mr-0.5" />
                {inviteEarnings.toFixed(2)}
              </div>
            </CardContent>
          </Card>
          <Card className="border-none shadow-sm">
            <CardContent className="p-4 text-center">
              <div className="text-xs text-muted-foreground mb-1">L2 Earnings</div>
              <div className="text-xl font-bold text-purple-600 flex items-center justify-center">
                <IndianRupee className="w-4 h-4 mr-0.5" />
                {inviteEarningsL2.toFixed(2)}
              </div>
            </CardContent>
          </Card>
        </div>

        {totalEarnings > 0 && (
          <Card className="border-none shadow-sm bg-green-50 border-green-100">
            <CardContent className="p-4 flex items-center justify-between">
              <div>
                <div className="text-xs text-muted-foreground">Total Commission Earned</div>
                <div className="text-2xl font-bold text-green-700 flex items-center">
                  <IndianRupee className="w-5 h-5 mr-0.5" />{totalEarnings.toFixed(2)}
                </div>
              </div>
              <TrendingUp className="w-8 h-8 text-green-400" />
            </CardContent>
          </Card>
        )}

        {/* Referral Code */}
        <Card className="border-none shadow-sm">
          <CardHeader className="pb-2">
            <CardTitle className="text-base">Your Referral Code</CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            <div className="bg-muted rounded-xl p-4 flex items-center justify-between">
              <span className="text-2xl font-bold tracking-widest text-primary">{referralCode}</span>
              <Button variant="ghost" size="icon" onClick={handleCopyCode}>
                <Copy className="w-4 h-4" />
              </Button>
            </div>
            <div className="grid grid-cols-2 gap-2">
              <Button type="button" variant="outline" onClick={handleCopyLink} className="rounded-xl">
                <Copy className="w-4 h-4 mr-2" /> Copy Link
              </Button>
              <Button type="button" onClick={handleShare} className="rounded-xl">
                <Share2 className="w-4 h-4 mr-2" /> Share
              </Button>
            </div>
          </CardContent>
        </Card>

        {/* Invite Image — shown when admin has uploaded one */}
        {inviteShareImageUrl && (
          <Card className="border-none shadow-sm overflow-hidden">
            <CardHeader className="pb-2">
              <CardTitle className="text-base">Invite Image</CardTitle>
            </CardHeader>
            <CardContent className="space-y-3 p-4 pt-0">
              <img
                src={inviteShareImageUrl}
                alt="Invite"
                className="w-full rounded-xl object-cover max-h-64"
              />
              <p className="text-xs text-muted-foreground text-center">
                Image save karo → WhatsApp/Telegram mein manually attach karke share karo
              </p>
              <Button
                type="button"
                variant="outline"
                onClick={handleSaveImage}
                className="w-full rounded-xl"
              >
                <Download className="w-4 h-4 mr-2" /> Save Image to Gallery
              </Button>
            </CardContent>
          </Card>
        )}

        {/* How it works */}
        <Card className="border-none shadow-sm">
          <CardHeader className="pb-2">
            <CardTitle className="text-base">How it Works</CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            {[
              { step: "1", title: "Share your code", desc: "Share your referral code or link with friends" },
              { step: "2", title: "Friend registers", desc: "They sign up using your referral code" },
              { step: "3", title: "Earn commission", desc: "Get 1% of every deposit your friend makes (L1)" },
              { step: "4", title: "Earn more (L2)", desc: "Get 0.1% from deposits of friends invited by your friends" },
            ].map((item) => (
              <div key={item.step} className="flex items-start gap-3">
                <div className="w-8 h-8 bg-primary/10 rounded-full flex items-center justify-center shrink-0 text-sm font-bold text-primary">
                  {item.step}
                </div>
                <div>
                  <div className="font-medium text-sm">{item.title}</div>
                  <div className="text-xs text-muted-foreground">{item.desc}</div>
                </div>
              </div>
            ))}
          </CardContent>
        </Card>

        <Card className="border-none shadow-sm">
          <CardHeader className="pb-2">
            <CardTitle className="text-base flex items-center gap-2">
              <Award className="w-4 h-4 text-primary" />
              Agent Criteria
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            <div className="grid grid-cols-2 gap-3">
              <div className="rounded-2xl bg-primary/10 p-4">
                <div className="text-xs text-muted-foreground">Today's active invite deposits</div>
                <div className="text-2xl font-bold text-primary flex items-center gap-1">
                  <Flame className="w-5 h-5" />
                  {todayActiveCount}
                </div>
              </div>
              <div className="rounded-2xl bg-emerald-50 p-4">
                <div className="text-xs text-muted-foreground">Invitees with today deposit</div>
                <div className="text-2xl font-bold text-emerald-700">{invitees.filter((u: any) => Number(u.todayDeposits || 0) > 0).length}</div>
              </div>
            </div>
            <div className="rounded-2xl bg-slate-900 p-4 text-white">
              <div className="text-xs text-white/70">Current daily reward at {todayActiveCount} active invite users</div>
              <div className="text-2xl font-bold">₹{Number(currentDailyReward || 0).toFixed(2)}</div>
            </div>
            <div className="space-y-2">
              {agentTiers.length === 0 ? (
                <div className="text-sm text-muted-foreground">Agent reward criteria currently not configured.</div>
              ) : (
                agentTiers.map((tier: any, idx: number) => {
                  const isReached = todayActiveCount >= Number(tier.minActiveDeposits || 0);
                  return (
                    <div key={`${tier.minActiveDeposits}-${idx}`} className={`rounded-2xl border p-3 ${isReached ? "bg-emerald-50 border-emerald-200" : "bg-white border-muted"}`}>
                      <div className="flex items-center justify-between gap-3">
                        <div>
                          <div className="font-semibold text-sm">{tier.label || `Tier ${idx + 1}`}</div>
                          <div className="text-xs text-muted-foreground">
                            {tier.minActiveDeposits}+ active invite deposits today
                          </div>
                        </div>
                        <div className={`text-sm font-bold ${isReached ? "text-emerald-700" : "text-slate-700"}`}>
                          ₹{Number(tier.reward || 0).toFixed(2)}
                        </div>
                      </div>
                    </div>
                  );
                })
              )}
            </div>
          </CardContent>
        </Card>

        <Card className="border-none shadow-sm">
          <CardHeader className="pb-2">
            <CardTitle className="text-base">Invited Users</CardTitle>
          </CardHeader>
          <CardContent className="space-y-2">
            {invitees.length === 0 ? (
              <div className="text-sm text-muted-foreground text-center py-4">No one has joined with your invite yet.</div>
            ) : (
              invitees.map((u: any) => (
                <div key={u.id} className="rounded-2xl border border-muted bg-white p-3 space-y-2">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2 min-w-0">
                      <div className="w-8 h-8 rounded-full bg-primary/10 text-primary flex items-center justify-center shrink-0">
                        <Users className="w-4 h-4" />
                      </div>
                      <div className="min-w-0">
                        <div className="font-semibold text-sm truncate">{u.displayName || u.username}</div>
                        <div className="text-[11px] text-muted-foreground">Joined with your code</div>
                      </div>
                    </div>
                    <div className="text-right shrink-0">
                      <div className="text-[10px] text-muted-foreground uppercase tracking-wide">Today commission</div>
                      <div className="text-sm font-bold text-green-600">₹{Number(u.todayCommission || 0).toFixed(2)}</div>
                    </div>
                  </div>
                  <div className="grid grid-cols-3 gap-2 pt-1">
                    <div className="rounded-lg bg-blue-50 p-2 text-center">
                      <div className="text-[10px] text-blue-600 uppercase">Today Deposit</div>
                      <div className="text-xs font-bold text-blue-700">₹{Number(u.todayDeposits || 0).toFixed(2)}</div>
                    </div>
                    <div className="rounded-lg bg-emerald-50 p-2 text-center">
                      <div className="text-[10px] text-emerald-600 uppercase">Total Deposit</div>
                      <div className="text-xs font-bold text-emerald-700">₹{Number(u.totalDeposits || 0).toFixed(2)}</div>
                    </div>
                    <div className="rounded-lg bg-purple-50 p-2 text-center">
                      <div className="text-[10px] text-purple-600 uppercase">Total Commission</div>
                      <div className="text-xs font-bold text-purple-700">₹{Number(u.lifetimeCommission || 0).toFixed(2)}</div>
                    </div>
                  </div>
                </div>
              ))
            )}
          </CardContent>
        </Card>

      </div>
    </Layout>
  );
}
